﻿using OnlineShop.Models.Products.Components;
using OnlineShop.Models.Products.Peripherals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OnlineShop.Models.Products.Computers
{
    public abstract class Computer : Product, IComputer
    {
        private List<IComponent> components;
        private List<IPeripheral> peripherals;

        protected Computer(int id, string manufacturer, string model, decimal price, double overallPerformance) 
            : base(id, manufacturer, model, price, overallPerformance)
        {
            components = new List<IComponent>();
            peripherals = new List<IPeripheral>();
            Components = new List<IComponent>();
            Peripherals = new List<IPeripheral>();
        }

        public IReadOnlyCollection<IComponent> Components { get; private set; }

        public IReadOnlyCollection<IPeripheral> Peripherals { get; private set; }

        public override double OverallPerformance => Components.Count() == 0 ? this.OverallPerformance : this.OverallPerformance + Components.Select(x => x.OverallPerformance).Sum();
        public override decimal Price => this.Price + Components.Select(x => x.Price).Sum() + Peripherals.Select(x => x.Price).Sum();
        public void AddComponent(IComponent component)
        {
            if (components.Contains(component))
            {
                throw new ArgumentException($"Component {component.GetType().Name} already exists in {this.GetType().Name} with Id {this.Id}.");
            }

            components.Add(component);

            Components = components;
        }

        public void AddPeripheral(IPeripheral peripheral)
        {
            if (peripherals.Contains(peripheral))
            {
                throw new ArgumentException($"Peripheral {peripheral.GetType().Name} already exists in {this.GetType().Name} with Id {this.Id}.");
            }

            peripherals.Add(peripheral);

            Peripherals = peripherals;
        }

        public IComponent RemoveComponent(string componentType)
        {
            IComponent component = components.FirstOrDefault(x => x.GetType().Name.ToString() == componentType);

            if (!components.Contains(component)||!components.Any())
            {
                throw new ArgumentException($"Component {componentType} does not exist in {this.GetType().Name} with Id {this.Id}.");
            }

            components.Remove(component);

            return component;
                
        }

        public IPeripheral RemovePeripheral(string peripheralType)
        {
            IPeripheral peripheral = peripherals.FirstOrDefault(x => x.GetType().Name.ToString() == peripheralType);

            if (!peripherals.Contains(peripheral) || !peripherals.Any())
            {
                throw new ArgumentException($"Peripheral {peripheralType} does not exist in {this.GetType().Name} with Id {this.Id}.");
            }

            peripherals.Remove(peripheral);

            return peripheral;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();

            var overPerfPerif = peripherals.Select(x => x.OverallPerformance).Average();

            sb.AppendLine($"Overall Performance: {this.OverallPerformance}. Price: {Price} - {this.GetType().Name}: {Manufacturer} {Model} (Id: {Id})");
            sb.AppendLine($" Components ({components.Count()}):");
            foreach (var component in components)
            {
                sb.AppendLine($"  {component}");
            }
            sb.AppendLine($" Peripherals ({peripherals.Count()}); Average Overall Performance ({overPerfPerif}):");
            foreach (var peripheral in peripherals)
            {
                sb.AppendLine($"  {peripheral}");
            }
            return sb.ToString().TrimEnd();
        }
    }
}
